/*
CIS22C
Lab 5
Author: Arshia Aravinthan
Purpose: This program evaluates the functionality of hashtables.
*/

#include <iostream>
#include <cmath>
#include "currency.cpp"
#include "dollar.cpp"
#include "HashTable.cpp"

using namespace std;


int main() {
  HashTable map;
  map.insert(new Dollar(57.12));
  map.insert(new Dollar(23.44));
  map.insert(new Dollar(87.43));
  map.insert(new Dollar(68.99));
  map.insert(new Dollar(111.22));
  map.insert(new Dollar(44.55));
  map.insert(new Dollar(77.77));
  map.insert(new Dollar(18.36));
  map.insert(new Dollar(543.21));
  map.insert(new Dollar(20.21));
  map.insert(new Dollar(345.67));
  map.insert(new Dollar(36.18));
  map.insert(new Dollar(48.48));
  map.insert(new Dollar(101.00));
  map.insert(new Dollar(11.00));
  map.insert(new Dollar(21.00));
  map.insert(new Dollar(51.00));
  map.insert(new Dollar(1.00));
  map.insert(new Dollar(251.00));
  map.insert(new Dollar(151.00));

  cout << "Number of items in hashtable: " << map.getSize() << endl;
  cout << "Load Factor: " << round(map.loadFactor()*100)/100 << endl;
  cout << "Number of collisions: " << map.getCollisions() << endl;

  double input = -12;
  while (input != -2) {
    cout << "\nEnter a dollar value to search for in the array or '-2' to quit: ";
    cin >> input;
    if (input == -2) break;
    int result = map.search(new Dollar(input));
    if (result == -1) cout << "Invalid Input.\n";
    else cout << result << endl;
  }

  system("pause");
  return 0;
}