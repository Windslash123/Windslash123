/*
CIS22C
Lab 5
Author: Arshia Aravinthan
Purpose: This program evaluates the functionality of hashtables.
*/

#ifndef DOLLAR_H
#define DOLLAR_H

#include <iostream>
#include "currency.cpp"
using namespace std;

class Dollar : public Currency {
  private:
    string currencyType = "Dollar";
    string getName() {return currencyType;}

  public:
    Dollar() : Currency() {    }
    Dollar(double val) : Currency(val) {    }
};


#endif