/*
CIS22C
Lab 5
Author: Arshia Aravinthan
Purpose: This program evaluates the functionality of hashtables.
*/

#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <iostream>
#include "currency.cpp"



using namespace std;

class HashTable {
public:
  int size;
  int buckets;
  int collisions = 0;
  struct HashNode {
    Currency* value;
  };

  HashNode** arr;
  
    HashTable(int ini_buck = 29) : size(0), buckets(ini_buck), arr(new HashNode*[buckets]) {
      for (int i = 0; i < buckets; i++) {
        arr[i] = NULL;
      }
    }
~HashTable()
        {
		for (int i = 0; i < buckets; i++)
                {
			 if (arr[i] != NULL){
				delete arr[i];
				arr[i] = NULL;
			}
		}
		delete[] arr;
	}

/** The function uses a pseudorandom scheme to create a hash for the inputted key
    *precondition - val - currency value
    *postcondition - none
    *return - int  
    */  
    int pseud(Currency* val) {
      int m = 2;
      int n = 3;
      int w = val->getNote();
      int f = val->getCoin();
      return (m*w + n*f) % buckets;
    }

/** The function inserts a value into the hashtable
    *precondition val - Currency value
    *postcondition - hashtable is appended
    *return - void  
    */ 
    void insert(Currency* val) {

      HashNode* node = new HashNode{val};
      int i;
      for (i = 0; i < buckets; i++) {
        int adr = (pseud(val) + i*i) % buckets;
        if ((arr[adr]) == NULL) {
          arr[adr] = node;
          size++;
          break;
        }
        
      }
      if (loadFactor() > 0.8 || i > buckets / 3) {
        rehash();
      } 
      collisions += i;
      return;
    }

/** The function searches for a Currency value in the hashtable
    *@precondition - val - Currency value to be searched for
    *@postcondition - none
    *@return - int  
    */ 
    int search(Currency* val) {
      HashNode* node = new HashNode{val};
      int i;
      for (i = 0; i < buckets; i++) {
        int adr = (pseud(val) + i*i) % buckets;
        if (arr[adr] == NULL) {
          return -1;
        }
        else if (arr[adr]->value->getNote() == node->value->getNote() && arr[adr]->value->getCoin() == node->value->getCoin()) {
          return adr;
        }
      
      }
      return -1;
    }

/** The function checks if a number is prime
    *@precondition - n - number to check if prime
    *@postcondition - none
    *@return - bool  
    */ 
    bool PrimeNum(int n){
        if (n == 2 || n == 3)
            return true;
        if (n % 2 == 0 || n % 3 == 0)
            return false;
        int div = 6;
        while (div * div - 2 * div + 1 <= n) {
            if (n % (div - 1) == 0)
                return false;
            if (n % (div + 1) == 0)
                return false;
            div += 6;
        }
        return true;
    }

/** The function finds a prime number iteratively
    *@precondition - x - intial number
    *@postcondition - none
    *@return - int  
    */ 
    int FindPrime(int x){
        while (!PrimeNum(++x)){
          }
        return x;
    }

/** The function rehashes once the hashtable is overloading
    *@precondition - none
    *@postcondition - none
    *@return - void  
    */ 
    void rehash() {
      int oldBuckets = buckets;
      collisions = 0;
      size = 0;
      buckets = FindPrime(buckets*2);
      HashNode** oldArray = arr;
      arr = new HashNode*[buckets]();
      
      for (int i = 0; i < oldBuckets; i++){
        if (oldArray[i] != NULL){
          for (int j = 0; j < buckets; j++){
            int ind = (pseud(oldArray[i]->value) + j*j) % buckets;
            if (arr[ind] == nullptr){
              arr[ind] = new HashNode {oldArray[i]->value};
              size++;
              break;
            } 
          } 
          delete oldArray[i];
          oldArray[i] = nullptr;
        } 
		} 

		delete[] oldArray;
    }

    double loadFactor() const {
      return (double(size) / buckets);
    }

    int getSize() {
      return size;
    }

    int getCollisions() {
      return collisions;
    }
};


#endif