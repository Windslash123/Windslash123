/*
CIS22C
Lab 5
Author: Arshia Aravinthan
Purpose: This program evaluates the functionality of hashtables.
*/

#ifndef CURRENCY_H
#define CURRENCY_H

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

class Currency {

  protected:
    int note;
    int coin;
    virtual string getName() = 0;

  public:
    Currency() {
      note = 0.00;
      coin = 0.00;
    }

    Currency(double num) {
      if (num < 0) {
        cout << "Currency cannot be negative. Invalid." << endl;
      return;
      }
      note = int(num);
      coin = round((num - note) * 100);
    }

    Currency(const Currency &val) {
      note = val.note;
      coin = val.coin;
    }

    int getNote() {return note;}
    int getCoin() {return coin;}

    void setNote(int whole) { if (whole >= 0) note = whole; }
    void setCoin(int fraction) { if (fraction >= 0 && fraction < 100) coin = fraction; }

    /*
    isEqual
    This algortihm checks if a currency value is equal to another.
    Pre: val - value to be compared
    Post: none
    Return: true or false
    */
    bool isEqual(const Currency &val) {
      return (val.coin == coin) && (val.note == note);
    }

    /*
    isGreater
    This algortihm checks if a currency value is greater than another.
    Pre: val - value to be compared
    Post: none
    Return: true or false
    */
    bool isGreater(const Currency &val) {
      if (note > val.note) return true;
      if ((note == val.note) && (coin > val.coin)) return true;
      return false;
    }

    /*
    add
    This algortihm adds a given amount of a currency to the same type of currency.
    Pre: val - the amount to add
    Post: none
    Return: void
    */
    void add(const Currency* val) {
      note += val->note;
      coin += val -> coin;
      if (coin >= 100) {
        note += 1;
        coin %= 100;
      }
      
    }
    /*
    subtract
    This algortihm subtracts a given amount of a currency from the same type of currency.
    Pre: val - the amount to subtract
    Post: none
    Return: void
    */
    void subtract(const Currency* val) {
      if (!isGreater(*val)) {
        cout <<  "Invalid subtraction." << endl;
        return;
      }
      note -= val->note;
      if (val->coin > coin) {
        note--;
        coin = coin + 100 - val->coin;
      }
      else coin -= val->coin;
    }
  
    /*
    toString
    This algortihm converts the integer currency value to a string along with its name.
    Pre: coin - currency coin value
         note - currency note value
    Post: none
    Return: string
    */
    string toString() {
      string coins;
      if (coin < 10) coins = "0" + to_string(coin);
      else coins = to_string(coin);
      string line = to_string(note) + "." + coins + " " + getName();
      return line;
  }

};

#endif